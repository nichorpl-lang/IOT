const int hijau1 = 26;
const int kuning1 = 25;
const int merah1 = 33;

const int hijau2 = 27;
const int kuning2 = 14;
const int merah2 = 12;

const int hijau3 = 17;
const int kuning3 = 16;
const int merah3 = 4;

const int hijau4 = 5;
const int kuning4 = 18;
const int merah4 = 19;

void setup(){
  pinMode(hijau1, OUTPUT);
  pinMode(kuning1, OUTPUT);
  pinMode(merah1, OUTPUT);

  pinMode(hijau2, OUTPUT);
  pinMode(kuning2, OUTPUT);
  pinMode(merah2, OUTPUT);

  pinMode(hijau3, OUTPUT);
  pinMode(kuning3, OUTPUT);
  pinMode(merah3, OUTPUT);

  pinMode(hijau4, OUTPUT);
  pinMode(kuning4, OUTPUT);
  pinMode(merah4, OUTPUT);
}
void loop(){
  digitalWrite(hijau1, HIGH);
  digitalWrite(kuning1, LOW);
  digitalWrite(merah1, LOW);
  delay(500);
  digitalWrite(hijau1, LOW);
  digitalWrite(kuning1, HIGH);
  digitalWrite(merah1, LOW);
  delay(500);
  digitalWrite(hijau1, LOW);
  digitalWrite(kuning1, LOW);
  digitalWrite(merah1, HIGH);
  delay(500);
  
   digitalWrite(hijau2, HIGH);
  digitalWrite(kuning2, LOW);
  digitalWrite(merah2, LOW);
  delay(500);
  digitalWrite(hijau2, LOW);
  digitalWrite(kuning2, HIGH);
  digitalWrite(merah2, LOW);
  delay(500);
  digitalWrite(hijau2, LOW);
  digitalWrite(kuning2, LOW);
  digitalWrite(merah2, HIGH);
  delay(500);
  
  digitalWrite(hijau3, HIGH);
  digitalWrite(kuning3, LOW);
  digitalWrite(merah3, LOW);
  delay(500);
  digitalWrite(hijau3, LOW);
  digitalWrite(kuning3, HIGH);
  digitalWrite(merah3, LOW);
  delay(500);
  digitalWrite(hijau3, LOW);
  digitalWrite(kuning3, LOW);
  digitalWrite(merah3, HIGH);
  delay(500);

   digitalWrite(hijau4, HIGH);
  digitalWrite(kuning4, LOW);
  digitalWrite(merah4, LOW);
  delay(500);
  digitalWrite(hijau4, LOW);
  digitalWrite(kuning4, HIGH);
  digitalWrite(merah4, LOW);
  delay(500);
  digitalWrite(hijau4, LOW);
  digitalWrite(kuning4, LOW);
  digitalWrite(merah4, HIGH);
  delay(500);
}
