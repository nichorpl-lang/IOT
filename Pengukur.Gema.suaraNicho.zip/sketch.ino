const int trigPin = 5;
const int echoPin = 18;

// Kecepatan suara di udara sekitar 0.034 cm/microsecond
#define SOUND_SPEED 0.034

long duration;
float distanceCm;

void setup() {
  Serial.begin(115200); // Memulai Serial Monitor ESP32
  pinMode(trigPin, OUTPUT);
  pinMode(echoPin, INPUT);
}

void loop() {
  // Membersihkan pin trigPin
  digitalWrite(trigPin, LOW);
  delayMicroseconds(2);
  
  // Mengaktifkan pin trigPin selama 10 mikrodetik
  digitalWrite(trigPin, HIGH);
  delayMicroseconds(10);
  digitalWrite(trigPin, LOW);
  
  // Membaca echoPin, mengembalikan waktu perjalanan gelombang suara dalam mikrodetik
  duration = pulseIn(echoPin, HIGH);
  
  // Menghitung jarak berdasarkan waktu gema
  distanceCm = duration * SOUND_SPEED / 2;
  
  // Menampilkan hasil ke Serial Monitor
  Serial.print("Waktu Gema: ");
  Serial.print(duration);
  Serial.print(" µs | Jarak: ");
  Serial.print(distanceCm);
  Serial.println(" cm");
  
  delay(1000);
}